#!/bin/sh
exec autoreconf -i
